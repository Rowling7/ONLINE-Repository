--备份库 更新了历史表
backup database [HRP-DBMS2014] to disk ='C:\HRP-DBMS2014-1226-1'

--备份库 更新了历史表
backup database [HRP-GHSS2014] to disk ='C:\HRP-GHSS2014-1226-1'

