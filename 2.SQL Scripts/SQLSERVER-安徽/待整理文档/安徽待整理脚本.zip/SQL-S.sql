--备份库 更新了历史表
backup database [HRP-DBMS2014] to disk ='E:\HRP-DBMS2014-0103-1'

--备份库 更新了历史表
backup database [HRP-GHSS2014] to disk ='E:\HRP-GHSS2014-0103-1'

